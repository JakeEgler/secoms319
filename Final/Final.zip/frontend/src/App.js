import React from "react";
import WeatherComponent from "./index";

function App() {
  return (
    <div>
      <WeatherComponent />
    </div>
  );
}

export default App;
