mongoose.connect("mongodb://localhost/assignment3", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});